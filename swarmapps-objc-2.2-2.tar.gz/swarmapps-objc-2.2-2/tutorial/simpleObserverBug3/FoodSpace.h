// FoodSpace.h

#import <space/Discrete2d.h>

@interface FoodSpace: Discrete2d 
{
}

- seedFoodWithProb: (float)s;

@end

