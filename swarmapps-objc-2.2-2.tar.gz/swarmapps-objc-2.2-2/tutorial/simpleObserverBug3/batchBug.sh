./bug --run=1 --randomSeed=2210 --bugDensity=0.3 --experimentDuration=40
./bug --run=2 --randomSeed=2250 --bugDensity=0.1 --experimentDuration=40
