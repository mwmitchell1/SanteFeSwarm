// dists.include.setting.m

// Code common to all distributions
// Random version 0.8
// 


-reset {
   return [self resetState];
}

// dists.include.setting.m

