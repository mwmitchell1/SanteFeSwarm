#define op_t unsigned long int
#define OPSIZ (sizeof(op_t))
typedef unsigned char byte;
