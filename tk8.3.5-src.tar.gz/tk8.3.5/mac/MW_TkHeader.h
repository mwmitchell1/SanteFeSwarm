#if __POWERPC__
#include "MW_TkHeaderPPC"
#elif __CFM68K__
#include "MW_TkHeaderCFM68K"
#else
#include "MW_TkHeader68K"
#endif
